-- MySQL dump 10.13  Distrib 8.4.11, for Linux (aarch64)
--
-- Host: db    Database: hotel
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('d0e1f2a3b4c5');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events`
--

DROP TABLE IF EXISTS `audit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `actor_user_id` int DEFAULT NULL,
  `action` varchar(80) NOT NULL,
  `entity_type` varchar(80) NOT NULL,
  `entity_id` int NOT NULL,
  `operation_key` varchar(120) DEFAULT NULL,
  `before_data` json DEFAULT NULL,
  `after_data` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `actor_user_id` (`actor_user_id`),
  KEY `ix_audit_events_hotel_created` (`hotel_id`,`created_at`),
  KEY `ix_audit_events_hotel_entity` (`hotel_id`,`entity_type`,`entity_id`),
  CONSTRAINT `audit_events_ibfk_1` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `audit_events_ibfk_2` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events`
--

LOCK TABLES `audit_events` WRITE;
/*!40000 ALTER TABLE `audit_events` DISABLE KEYS */;
INSERT INTO `audit_events` VALUES (1,1,1,'create_refund','booking',1,'refund:1:live-wrong','{\"cap\": \"500000.00\", \"already_refunded\": \"0.00\"}','{\"base\": \"total\", \"reason\": \"Nhap nham 70%\", \"percent\": null, \"base_value\": \"2000000.00\", \"refund_amount\": \"350000.00\", \"payment_method\": \"cash\"}','2026-08-14 09:00:09'),(2,1,1,'reverse_refund','payment',2,'refund_reversal:2:live-fix','{\"note\": \"Hoàn tiền đơn BK-SMOKE-01: Nhap nham 70%\", \"refund_amount\": \"-350000.00\"}','{\"amount\": \"350000.00\", \"reason\": \"Nhap nham, dao lai\", \"reversal_payment_id\": 3}','2026-08-14 09:00:09'),(3,1,1,'create_refund','booking',1,'refund:1:live-correct','{\"cap\": \"500000.00\", \"already_refunded\": \"0.00\"}','{\"base\": \"total\", \"reason\": \"Hoan dung 7%\", \"percent\": null, \"base_value\": \"2000000.00\", \"refund_amount\": \"35000.00\", \"payment_method\": \"cash\"}','2026-08-14 09:00:09');
/*!40000 ALTER TABLE `audit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_reschedules`
--

DROP TABLE IF EXISTS `booking_reschedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_reschedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `booking_room_id` int NOT NULL,
  `old_room_id` int NOT NULL,
  `new_room_id` int NOT NULL,
  `old_check_in` datetime NOT NULL,
  `old_check_out` datetime NOT NULL,
  `new_check_in` datetime NOT NULL,
  `new_check_out` datetime NOT NULL,
  `reason` varchar(255) NOT NULL,
  `price_mode` varchar(20) NOT NULL,
  `actor_user_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_reschedules`
--

LOCK TABLES `booking_reschedules` WRITE;
/*!40000 ALTER TABLE `booking_reschedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_reschedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_rooms`
--

DROP TABLE IF EXISTS `booking_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_rooms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `room_id` int NOT NULL,
  `check_in_expected` datetime DEFAULT NULL,
  `check_out_expected` datetime DEFAULT NULL,
  `check_in_actual` datetime DEFAULT NULL,
  `check_out_actual` datetime DEFAULT NULL,
  `rental_type` varchar(20) DEFAULT NULL,
  `price_snapshot` decimal(15,2) DEFAULT NULL,
  `room_deposit_amount` decimal(15,2) DEFAULT NULL,
  `room_deposit_original` decimal(15,2) DEFAULT NULL,
  `cancellation_refund_percent` decimal(5,2) DEFAULT NULL,
  `cancellation_fee_percent` decimal(5,2) DEFAULT NULL,
  `cancellation_refund_amount` decimal(15,2) DEFAULT NULL,
  `final_amount` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `price_breakdown_snapshot` json DEFAULT NULL,
  `hourly_price_snapshot` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  KEY `ix_booking_rooms_booking_id_status` (`booking_id`,`status`),
  KEY `ix_booking_rooms_status` (`status`),
  KEY `fk_booking_rooms_hotel` (`hotel_id`),
  CONSTRAINT `booking_rooms_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`),
  CONSTRAINT `booking_rooms_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  CONSTRAINT `fk_booking_rooms_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_rooms`
--

LOCK TABLES `booking_rooms` WRITE;
/*!40000 ALTER TABLE `booking_rooms` DISABLE KEYS */;
INSERT INTO `booking_rooms` VALUES (1,1,1,'2026-08-10 07:00:00','2026-08-15 07:00:00','2026-08-10 07:00:00',NULL,'daily',400000.00,0.00,0.00,0.00,0.00,0.00,0.00,'checked_in',1,'[{\"amount\": 400000.0, \"business_date\": \"2026-08-10\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-11\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-12\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-13\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-14\"}]',NULL);
/*!40000 ALTER TABLE `booking_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_service_batch_allocations`
--

DROP TABLE IF EXISTS `booking_service_batch_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_service_batch_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `booking_service_id` int NOT NULL,
  `batch_id` int NOT NULL,
  `quantity` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_booking_service_batch_allocation` (`hotel_id`,`booking_service_id`,`batch_id`),
  KEY `ix_booking_service_batch_allocations_hotel_id` (`hotel_id`),
  KEY `ix_booking_service_batch_allocations_booking_service_id` (`booking_service_id`),
  KEY `ix_booking_service_batch_allocations_batch_id` (`batch_id`),
  CONSTRAINT `booking_service_batch_allocations_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `inventory_batches` (`id`),
  CONSTRAINT `booking_service_batch_allocations_ibfk_2` FOREIGN KEY (`booking_service_id`) REFERENCES `booking_services` (`id`),
  CONSTRAINT `booking_service_batch_allocations_ibfk_3` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_service_batch_allocations`
--

LOCK TABLES `booking_service_batch_allocations` WRITE;
/*!40000 ALTER TABLE `booking_service_batch_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_service_batch_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_services`
--

DROP TABLE IF EXISTS `booking_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `room_id` int NOT NULL,
  `service_id` int NOT NULL,
  `quantity` int DEFAULT NULL,
  `price_at_booking` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_id` (`booking_id`),
  KEY `room_id` (`room_id`),
  KEY `service_id` (`service_id`),
  KEY `fk_booking_services_hotel` (`hotel_id`),
  CONSTRAINT `booking_services_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`),
  CONSTRAINT `booking_services_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  CONSTRAINT `booking_services_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `fk_booking_services_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_services`
--

LOCK TABLES `booking_services` WRITE;
/*!40000 ALTER TABLE `booking_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `customer_id` int NOT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `prepaid_amount` decimal(15,2) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `customer_id` (`customer_id`),
  KEY `ix_bookings_status` (`status`),
  KEY `fk_bookings_hotel` (`hotel_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_bookings_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (1,'BK-SMOKE-01',1,0.00,0.00,'partial','pending',NULL,'walk_in','2026-08-14 08:59:47','2026-08-14 08:59:47',1,NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_operations`
--

DROP TABLE IF EXISTS `business_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `operation_key` varchar(120) NOT NULL,
  `action` varchar(50) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `request_fingerprint` varchar(64) DEFAULT NULL,
  `result_snapshot` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_hotel_operation_key_uc` (`hotel_id`,`operation_key`),
  KEY `ix_business_operations_hotel_entity` (`hotel_id`,`entity_type`,`entity_id`),
  CONSTRAINT `business_operations_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_operations`
--

LOCK TABLES `business_operations` WRITE;
/*!40000 ALTER TABLE `business_operations` DISABLE KEYS */;
INSERT INTO `business_operations` VALUES (1,1,'refund:1:live-wrong','create_refund','booking',1,'completed','2026-08-14 09:00:09','2026-08-14 09:00:09','03725767bfcdf68bf8bc9dae1daffff51a73e08760d22e2e04a6b200a7ab52c0','{\"base\": \"total\", \"percent\": null, \"success\": true, \"payment_id\": 2, \"refund_amount\": \"350000.00\"}'),(2,1,'refund_reversal:2:live-fix','reverse_refund','payment',2,'completed','2026-08-14 09:00:09','2026-08-14 09:00:09','3517efec2c336ed5eddeaae1873427fdbde63a40cb5cfe2780994b16d6629d58','{\"amount\": \"350000.00\", \"success\": true, \"payment_id\": 3, \"reverses_payment_id\": 2}'),(3,1,'refund:1:live-correct','create_refund','booking',1,'completed','2026-08-14 09:00:09','2026-08-14 09:00:09','07712d2c654c2bec2211d378193863b6cc7ee7421d2c237b4c686223e8716b2f','{\"base\": \"total\", \"percent\": null, \"success\": true, \"payment_id\": 4, \"refund_amount\": \"35000.00\"}');
/*!40000 ALTER TABLE `business_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `cccd` varchar(12) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cccd` (`cccd`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_customers_hotel` (`hotel_id`),
  CONSTRAINT `fk_customers_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Nguyen Van A','0901234567',NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `expense_date` date NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `is_voided` tinyint(1) NOT NULL DEFAULT '0',
  `void_reason` varchar(255) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `voided_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `fk_expenses_hotel` (`hotel_id`),
  KEY `fk_expenses_voided_by_users` (`voided_by`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_expenses_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `fk_expenses_voided_by_users` FOREIGN KEY (`voided_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotels`
--

DROP TABLE IF EXISTS `hotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `address` text,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotels`
--

LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
INSERT INTO `hotels` VALUES (1,'Khách sạn Trung tâm','central',NULL,NULL,NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_batches`
--

DROP TABLE IF EXISTS `inventory_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `inventory_item_id` int NOT NULL,
  `expense_id` int DEFAULT NULL,
  `batch_code` varchar(64) NOT NULL,
  `received_at` date NOT NULL,
  `expires_at` date DEFAULT NULL,
  `quantity_received` int NOT NULL,
  `quantity_available` int NOT NULL,
  `unit_cost` decimal(15,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_hotel_inventory_batch_code_uc` (`hotel_id`,`batch_code`),
  KEY `created_by` (`created_by`),
  KEY `expense_id` (`expense_id`),
  KEY `ix_inventory_batches_hotel_id` (`hotel_id`),
  KEY `ix_inventory_batches_inventory_item_id` (`inventory_item_id`),
  CONSTRAINT `inventory_batches_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_batches_ibfk_2` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`),
  CONSTRAINT `inventory_batches_ibfk_3` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `inventory_batches_ibfk_4` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_batches`
--

LOCK TABLES `inventory_batches` WRITE;
/*!40000 ALTER TABLE `inventory_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `min_quantity` int DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `service_id` int DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `service_id` (`service_id`),
  KEY `fk_inventory_items_hotel` (`hotel_id`),
  CONSTRAINT `fk_inventory_items_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `inventory_items_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movements`
--

DROP TABLE IF EXISTS `inventory_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `inventory_item_id` int NOT NULL,
  `batch_id` int DEFAULT NULL,
  `expense_id` int DEFAULT NULL,
  `booking_service_id` int DEFAULT NULL,
  `movement_type` varchar(20) NOT NULL,
  `quantity_delta` int NOT NULL,
  `reason` varchar(100) NOT NULL,
  `note` varchar(500) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `booking_service_id` (`booking_service_id`),
  KEY `created_by` (`created_by`),
  KEY `expense_id` (`expense_id`),
  KEY `ix_inventory_movements_hotel_id` (`hotel_id`),
  KEY `ix_inventory_movements_inventory_item_id` (`inventory_item_id`),
  KEY `ix_inventory_movements_batch_id` (`batch_id`),
  CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `inventory_batches` (`id`),
  CONSTRAINT `inventory_movements_ibfk_2` FOREIGN KEY (`booking_service_id`) REFERENCES `booking_services` (`id`),
  CONSTRAINT `inventory_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_movements_ibfk_4` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`),
  CONSTRAINT `inventory_movements_ibfk_5` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `inventory_movements_ibfk_6` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movements`
--

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `note` text,
  `created_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `business_operation_id` int DEFAULT NULL,
  `component_key` varchar(120) DEFAULT NULL,
  `reverses_payment_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payments_operation_component` (`hotel_id`,`business_operation_id`,`component_key`),
  UNIQUE KEY `uq_payments_reverses_once` (`reverses_payment_id`),
  KEY `ix_payments_booking_id` (`booking_id`),
  KEY `fk_payments_business_operation` (`business_operation_id`),
  KEY `ix_payments_hotel_booking` (`hotel_id`,`booking_id`),
  KEY `fk_payments_created_by_user` (`created_by`),
  CONSTRAINT `fk_payments_business_operation` FOREIGN KEY (`business_operation_id`) REFERENCES `business_operations` (`id`),
  CONSTRAINT `fk_payments_created_by_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_payments_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `fk_payments_reverses_payment` FOREIGN KEY (`reverses_payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,500000.00,'cash','deposit','Cọc smoke','2026-08-14 08:59:47',1,NULL,NULL,NULL,NULL),(2,1,-350000.00,'cash','refund','Hoàn tiền đơn BK-SMOKE-01: Nhap nham 70%','2026-08-14 09:00:09',1,1,'refund',NULL,NULL),(3,1,350000.00,'cash','refund_reversal','Điều chỉnh hoàn sai (dòng #2): Nhap nham, dao lai','2026-08-14 09:00:09',1,2,'refund_reversal',2,NULL),(4,1,-35000.00,'cash','refund','Hoàn tiền đơn BK-SMOKE-01: Hoan dung 7%','2026-08-14 09:00:09',1,3,'refund',NULL,NULL);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_rules`
--

DROP TABLE IF EXISTS `price_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `days_of_week` varchar(20) DEFAULT NULL,
  `price_daily` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_price_rules_hotel` (`hotel_id`),
  CONSTRAINT `fk_price_rules_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_rules`
--

LOCK TABLES `price_rules` WRITE;
/*!40000 ALTER TABLE `price_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `room_number` varchar(10) NOT NULL,
  `room_type` varchar(20) DEFAULT NULL,
  `price_per_night` int NOT NULL,
  `price_initial_block` int NOT NULL,
  `initial_hours` int NOT NULL,
  `price_next_hour` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `clean_status` varchar(20) DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rooms_hotel_room_number` (`hotel_id`,`room_number`),
  CONSTRAINT `fk_rooms_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,'101','Standard',400000,100000,2,50000.00,'available','cleaned',1);
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_services_hotel` (`hotel_id`),
  CONSTRAINT `fk_services_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `fs_uniquifier` varchar(64) NOT NULL,
  `hotel_id` int DEFAULT NULL,
  `is_super_admin` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fs_uniquifier` (`fs_uniquifier`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_users_hotel` (`hotel_id`),
  CONSTRAINT `fk_users_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','scrypt:32768:8:1$xDY4k186XczTQrtM$0bbe0a20ab283e9f3f3d1eaf3e892e271e595f6f90680d2b9eb4fc3a1cd283d22f176535e973cdb16feb4e6721f709d0c46977bda081d45f46681109990c7c8d','admin','280208fa-1177-42bd-8575-90e80dcf5cf4',1,0),(2,'staff1','scrypt:32768:8:1$WXR3mysQyp7WhTHK$b2fe8a27bdda9359584581e349fc60a074b0a8e8974dd8c409baa179b9b703d6368065051c0e315162bed629a06a60242ed3ad3fdcec6ccfb30729a14e1cac07','staff','80a25fc8-b205-4ea6-9840-484e16cee164',1,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'hotel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-15  3:19:26
