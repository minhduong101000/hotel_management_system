-- MySQL dump 10.13  Distrib 8.4.11, for Linux (aarch64)
--
-- Host: db    Database: hotel
-- ------------------------------------------------------
-- Server version	8.4.11

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('d0e1f2a3b4c5');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audit_events`
--

DROP TABLE IF EXISTS `audit_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audit_events` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `actor_user_id` int DEFAULT NULL,
  `action` varchar(80) NOT NULL,
  `entity_type` varchar(80) NOT NULL,
  `entity_id` int NOT NULL,
  `operation_key` varchar(120) DEFAULT NULL,
  `before_data` json DEFAULT NULL,
  `after_data` json DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `actor_user_id` (`actor_user_id`),
  KEY `ix_audit_events_hotel_created` (`hotel_id`,`created_at`),
  KEY `ix_audit_events_hotel_entity` (`hotel_id`,`entity_type`,`entity_id`),
  CONSTRAINT `audit_events_ibfk_1` FOREIGN KEY (`actor_user_id`) REFERENCES `users` (`id`),
  CONSTRAINT `audit_events_ibfk_2` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=72 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_events`
--

LOCK TABLES `audit_events` WRITE;
/*!40000 ALTER TABLE `audit_events` DISABLE KEYS */;
INSERT INTO `audit_events` VALUES (1,1,1,'create_refund','booking',1,'refund:1:live-wrong','{\"cap\": \"500000.00\", \"already_refunded\": \"0.00\"}','{\"base\": \"total\", \"reason\": \"Nhap nham 70%\", \"percent\": null, \"base_value\": \"2000000.00\", \"refund_amount\": \"350000.00\", \"payment_method\": \"cash\"}','2026-08-14 09:00:09'),(2,1,1,'reverse_refund','payment',2,'refund_reversal:2:live-fix','{\"note\": \"Hoàn tiền đơn BK-SMOKE-01: Nhap nham 70%\", \"refund_amount\": \"-350000.00\"}','{\"amount\": \"350000.00\", \"reason\": \"Nhap nham, dao lai\", \"reversal_payment_id\": 3}','2026-08-14 09:00:09'),(3,1,1,'create_refund','booking',1,'refund:1:live-correct','{\"cap\": \"500000.00\", \"already_refunded\": \"0.00\"}','{\"base\": \"total\", \"reason\": \"Hoan dung 7%\", \"percent\": null, \"base_value\": \"2000000.00\", \"refund_amount\": \"35000.00\", \"payment_method\": \"cash\"}','2026-08-14 09:00:09'),(4,1,1,'create_room','room',2,NULL,'null','{\"status\": \"available\", \"room_type\": \"Standard\", \"room_number\": \"701\", \"clean_status\": \"cleaned\", \"initial_hours\": 2, \"price_next_hour\": 50000.0, \"price_per_night\": 500000.0, \"price_initial_block\": 100000.0}','2026-08-15 04:30:57'),(5,1,1,'create_room','room',3,NULL,'null','{\"status\": \"available\", \"room_type\": \"Standard\", \"room_number\": \"702\", \"clean_status\": \"cleaned\", \"initial_hours\": 2, \"price_next_hour\": 50000.0, \"price_per_night\": 500000.0, \"price_initial_block\": 100000.0}','2026-08-15 04:30:57'),(6,1,1,'create_booking','booking_room',2,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-5VWZ\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-07-11T14:00:00\", \"check_out_expected\": \"2027-07-12T12:00:00\"}','2026-08-15 04:30:57'),(7,1,1,'create_booking','booking_room',3,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-56T3\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-07-13T14:00:00\", \"check_out_expected\": \"2027-07-14T12:00:00\"}','2026-08-15 04:32:12'),(8,1,1,'create_booking','booking_room',4,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-W9AP\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2026-11-27T14:00:00\", \"check_out_expected\": \"2026-11-28T12:00:00\"}','2026-08-15 04:33:08'),(9,1,1,'create_booking','booking_room',5,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-5CG6\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-05-03T14:00:00\", \"check_out_expected\": \"2027-05-04T12:00:00\"}','2026-08-15 04:33:10'),(10,1,1,'create_booking','booking_room',6,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-6WDS\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-09-24T14:00:00\", \"check_out_expected\": \"2027-09-25T12:00:00\"}','2026-08-15 04:33:11'),(11,1,1,'create_booking','booking_room',7,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-5NH8\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2028-07-17T14:00:00\", \"check_out_expected\": \"2028-07-18T12:00:00\"}','2026-08-15 04:33:54'),(12,1,1,'create_booking','booking_room',8,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-M3MY\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2031-01-13T14:00:00\", \"check_out_expected\": \"2031-01-14T12:00:00\"}','2026-08-15 04:35:04'),(13,1,1,'create_booking','booking_room',9,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-EG5S\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2031-06-19T14:00:00\", \"check_out_expected\": \"2031-06-20T12:00:00\"}','2026-08-15 04:35:06'),(14,1,1,'create_booking','booking_room',10,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-QYQT\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2031-11-10T14:00:00\", \"check_out_expected\": \"2031-11-11T12:00:00\"}','2026-08-15 04:35:07'),(15,1,1,'add_room_to_booking','booking_room',11,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-QYQT\", \"check_in_expected\": \"2031-11-10T14:00:00\", \"check_out_expected\": \"2031-11-11T12:00:00\"}','2026-08-15 04:35:08'),(16,1,1,'create_booking','booking_room',12,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-QV8Q\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2031-08-09T14:00:00\", \"check_out_expected\": \"2031-08-10T12:00:00\"}','2026-08-15 04:35:20'),(17,1,1,'add_room_to_booking','booking_room',13,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-QV8Q\", \"check_in_expected\": \"2031-08-09T14:00:00\", \"check_out_expected\": \"2031-08-10T12:00:00\"}','2026-08-15 04:35:21'),(18,1,1,'create_booking','booking_room',14,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-ELFW\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2032-04-12T14:00:00\", \"check_out_expected\": \"2032-04-13T12:00:00\"}','2026-08-15 04:35:39'),(19,1,1,'create_booking','booking_room',15,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-7NNA\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2032-09-16T14:00:00\", \"check_out_expected\": \"2032-09-17T12:00:00\"}','2026-08-15 04:35:41'),(20,1,1,'create_booking','booking_room',16,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-FZQA\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2033-02-07T14:00:00\", \"check_out_expected\": \"2033-02-08T12:00:00\"}','2026-08-15 04:35:42'),(21,1,1,'add_room_to_booking','booking_room',17,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-FZQA\", \"check_in_expected\": \"2033-02-07T14:00:00\", \"check_out_expected\": \"2033-02-08T12:00:00\"}','2026-08-15 04:35:44'),(22,1,1,'create_booking','booking_room',18,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-T3PP\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2033-08-06T14:00:00\", \"check_out_expected\": \"2033-08-07T12:00:00\"}','2026-08-15 04:36:16'),(23,1,1,'create_booking','booking_room',19,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-4TGR\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-06-29T14:00:00\", \"check_out_expected\": \"2027-06-30T12:00:00\"}','2026-08-15 07:11:06'),(24,1,1,'create_booking','booking_room',20,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-YSBJ\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-12-03T14:00:00\", \"check_out_expected\": \"2027-12-04T12:00:00\"}','2026-08-15 07:11:08'),(25,1,1,'create_booking','booking_room',21,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-MFMB\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2028-05-08T14:00:00\", \"check_out_expected\": \"2028-05-09T12:00:00\"}','2026-08-15 07:11:10'),(26,1,1,'add_room_to_booking','booking_room',22,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-MFMB\", \"check_in_expected\": \"2028-05-08T14:00:00\", \"check_out_expected\": \"2028-05-09T12:00:00\"}','2026-08-15 07:11:12'),(27,1,1,'create_booking','booking_room',23,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-NXAY\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2033-02-17T14:00:00\", \"check_out_expected\": \"2033-02-18T12:00:00\"}','2026-08-15 07:21:26'),(28,1,1,'create_booking','booking_room',24,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-WC3T\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2033-12-15T14:00:00\", \"check_out_expected\": \"2033-12-16T12:00:00\"}','2026-08-15 07:21:29'),(29,1,1,'create_booking','booking_room',25,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-AD2H\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2034-05-21T14:00:00\", \"check_out_expected\": \"2034-05-22T12:00:00\"}','2026-08-15 07:21:31'),(30,1,1,'add_room_to_booking','booking_room',26,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-AD2H\", \"check_in_expected\": \"2034-05-21T14:00:00\", \"check_out_expected\": \"2034-05-22T12:00:00\"}','2026-08-15 07:21:32'),(31,1,1,'create_booking','booking_room',27,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-8BV9\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-01-04T14:00:00\", \"check_out_expected\": \"2029-01-05T12:00:00\"}','2026-08-15 07:23:21'),(32,1,1,'create_booking','booking_room',28,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-W9J6\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-06-23T14:00:00\", \"check_out_expected\": \"2029-06-24T12:00:00\"}','2026-08-15 07:23:24'),(33,1,1,'create_booking','booking_room',29,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-YB5G\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-11-27T14:00:00\", \"check_out_expected\": \"2029-11-28T12:00:00\"}','2026-08-15 07:23:26'),(34,1,1,'add_room_to_booking','booking_room',30,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-YB5G\", \"check_in_expected\": \"2029-11-27T14:00:00\", \"check_out_expected\": \"2029-11-28T12:00:00\"}','2026-08-15 07:23:27'),(35,1,1,'create_booking','booking_room',31,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-57ZT\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2034-11-13T14:00:00\", \"check_out_expected\": \"2034-11-14T12:00:00\"}','2026-08-15 13:58:24'),(36,1,1,'create_booking','booking_room',32,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-XDUS\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-01-18T14:00:00\", \"check_out_expected\": \"2027-01-19T12:00:00\"}','2026-08-15 13:58:25'),(37,1,1,'create_booking','booking_room',33,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-JTSK\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-07-20T14:00:00\", \"check_out_expected\": \"2027-07-21T12:00:00\"}','2026-08-15 13:58:29'),(38,1,1,'add_room_to_booking','booking_room',34,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-JTSK\", \"check_in_expected\": \"2027-07-20T14:00:00\", \"check_out_expected\": \"2027-07-21T12:00:00\"}','2026-08-15 13:58:30'),(39,1,1,'create_booking','booking_room',35,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-89EA\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-11-11T14:00:00\", \"check_out_expected\": \"2029-11-12T12:00:00\"}','2026-08-15 14:19:08'),(40,1,1,'create_booking','booking_room',36,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-H9PV\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2030-04-30T14:00:00\", \"check_out_expected\": \"2030-05-01T12:00:00\"}','2026-08-15 14:19:11'),(41,1,1,'create_booking','booking_room',37,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-UKVH\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2030-10-30T14:00:00\", \"check_out_expected\": \"2030-10-31T12:00:00\"}','2026-08-15 14:19:15'),(42,1,1,'add_room_to_booking','booking_room',38,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-UKVH\", \"check_in_expected\": \"2030-10-30T14:00:00\", \"check_out_expected\": \"2030-10-31T12:00:00\"}','2026-08-15 14:19:16'),(43,1,1,'create_booking','booking_room',39,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-LBUP\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2034-09-27T14:00:00\", \"check_out_expected\": \"2034-09-28T12:00:00\"}','2026-08-15 14:21:25'),(44,1,1,'create_booking','booking_room',40,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-UGJ6\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2026-12-15T14:00:00\", \"check_out_expected\": \"2026-12-16T12:00:00\"}','2026-08-15 14:21:27'),(45,1,1,'create_booking','booking_room',41,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260815-L2U4\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-05-08T14:00:00\", \"check_out_expected\": \"2027-05-09T12:00:00\"}','2026-08-15 14:21:28'),(46,1,1,'add_room_to_booking','booking_room',42,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260815-L2U4\", \"check_in_expected\": \"2027-05-08T14:00:00\", \"check_out_expected\": \"2027-05-09T12:00:00\"}','2026-08-15 14:21:29'),(47,1,1,'create_booking','booking_room',43,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-CGWN\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-06-28T14:00:00\", \"check_out_expected\": \"2027-06-29T12:00:00\"}','2026-08-19 15:48:01'),(48,1,1,'create_booking','booking_room',44,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-DFW3\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-12-02T14:00:00\", \"check_out_expected\": \"2027-12-03T12:00:00\"}','2026-08-19 15:48:03'),(49,1,1,'create_booking','booking_room',45,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-QHAM\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2028-05-07T14:00:00\", \"check_out_expected\": \"2028-05-08T12:00:00\"}','2026-08-19 15:48:05'),(50,1,1,'add_room_to_booking','booking_room',46,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260819-QHAM\", \"check_in_expected\": \"2028-05-07T14:00:00\", \"check_out_expected\": \"2028-05-08T12:00:00\"}','2026-08-19 15:48:06'),(51,1,1,'create_booking','booking_room',47,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-KM6J\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2028-12-25T14:00:00\", \"check_out_expected\": \"2028-12-26T12:00:00\"}','2026-08-19 15:48:43'),(52,1,1,'create_booking','booking_room',48,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-U8PK\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-05-31T14:00:00\", \"check_out_expected\": \"2029-06-01T12:00:00\"}','2026-08-19 15:48:45'),(53,1,1,'create_booking','booking_room',49,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-JM2K\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-10-22T14:00:00\", \"check_out_expected\": \"2029-10-23T12:00:00\"}','2026-08-19 15:48:46'),(54,1,1,'add_room_to_booking','booking_room',50,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260819-JM2K\", \"check_in_expected\": \"2029-10-22T14:00:00\", \"check_out_expected\": \"2029-10-23T12:00:00\"}','2026-08-19 15:48:47'),(55,1,1,'create_booking','booking_room',51,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-YKY2\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2026-11-25T14:00:00\", \"check_out_expected\": \"2026-11-26T12:00:00\"}','2026-08-19 15:55:26'),(56,1,1,'create_booking','booking_room',52,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-QY4N\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-05-01T14:00:00\", \"check_out_expected\": \"2027-05-02T12:00:00\"}','2026-08-19 15:55:28'),(57,1,1,'create_booking','booking_room',53,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260819-TG2A\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-09-22T14:00:00\", \"check_out_expected\": \"2027-09-23T12:00:00\"}','2026-08-19 15:55:29'),(58,1,1,'add_room_to_booking','booking_room',54,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260819-TG2A\", \"check_in_expected\": \"2027-09-22T14:00:00\", \"check_out_expected\": \"2027-09-23T12:00:00\"}','2026-08-19 15:55:30'),(59,1,1,'create_booking','booking_room',55,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-NRFB\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-12-03T14:00:00\", \"check_out_expected\": \"2029-12-04T12:00:00\"}','2026-08-19 18:07:37'),(60,1,1,'create_booking','booking_room',56,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-AVZF\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2030-04-26T14:00:00\", \"check_out_expected\": \"2030-04-27T12:00:00\"}','2026-08-19 18:07:38'),(61,1,1,'create_booking','booking_room',57,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-CQMR\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2030-09-17T14:00:00\", \"check_out_expected\": \"2030-09-18T12:00:00\"}','2026-08-19 18:07:39'),(62,1,1,'add_room_to_booking','booking_room',58,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260820-CQMR\", \"check_in_expected\": \"2030-09-17T14:00:00\", \"check_out_expected\": \"2030-09-18T12:00:00\"}','2026-08-19 18:07:40'),(63,1,1,'create_booking','booking_room',59,NULL,'null','{\"status\": \"checked_in\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-UD56\", \"deposit_amount\": 500000.0, \"check_in_expected\": \"2026-08-20T01:09:00\", \"check_out_expected\": \"2026-08-21T12:00:00\"}','2026-08-19 18:09:04'),(64,1,1,'create_booking','booking_room',60,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-UEW5\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-02-14T14:00:00\", \"check_out_expected\": \"2027-02-15T12:00:00\"}','2026-08-19 18:44:46'),(65,1,1,'create_booking','booking_room',61,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-XKJ9\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-07-21T14:00:00\", \"check_out_expected\": \"2027-07-22T12:00:00\"}','2026-08-19 18:44:48'),(66,1,1,'create_booking','booking_room',62,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260820-9VS3\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2027-12-12T14:00:00\", \"check_out_expected\": \"2027-12-13T12:00:00\"}','2026-08-19 18:44:49'),(67,1,1,'add_room_to_booking','booking_room',63,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260820-9VS3\", \"check_in_expected\": \"2027-12-12T14:00:00\", \"check_out_expected\": \"2027-12-13T12:00:00\"}','2026-08-19 18:44:50'),(68,1,1,'create_booking','booking_room',64,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260821-4JS7\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2028-05-22T14:00:00\", \"check_out_expected\": \"2028-05-23T12:00:00\"}','2026-08-21 10:37:40'),(69,1,1,'create_booking','booking_room',65,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260821-W8HY\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2028-12-17T14:00:00\", \"check_out_expected\": \"2028-12-18T12:00:00\"}','2026-08-21 10:37:46'),(70,1,1,'create_booking','booking_room',66,NULL,'null','{\"status\": \"booked\", \"room_number\": \"701\", \"booking_code\": \"BK-260821-2TAZ\", \"deposit_amount\": 250000.0, \"check_in_expected\": \"2029-06-05T14:00:00\", \"check_out_expected\": \"2029-06-06T12:00:00\"}','2026-08-21 10:37:49'),(71,1,1,'add_room_to_booking','booking_room',67,NULL,'null','{\"room_number\": \"702\", \"booking_code\": \"BK-260821-2TAZ\", \"check_in_expected\": \"2029-06-05T14:00:00\", \"check_out_expected\": \"2029-06-06T12:00:00\"}','2026-08-21 10:37:50');
/*!40000 ALTER TABLE `audit_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_reschedules`
--

DROP TABLE IF EXISTS `booking_reschedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_reschedules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `booking_room_id` int NOT NULL,
  `old_room_id` int NOT NULL,
  `new_room_id` int NOT NULL,
  `old_check_in` datetime NOT NULL,
  `old_check_out` datetime NOT NULL,
  `new_check_in` datetime NOT NULL,
  `new_check_out` datetime NOT NULL,
  `reason` varchar(255) NOT NULL,
  `price_mode` varchar(20) NOT NULL,
  `actor_user_id` int NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_reschedules`
--

LOCK TABLES `booking_reschedules` WRITE;
/*!40000 ALTER TABLE `booking_reschedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_reschedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_rooms`
--

DROP TABLE IF EXISTS `booking_rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_rooms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `room_id` int NOT NULL,
  `check_in_expected` datetime DEFAULT NULL,
  `check_out_expected` datetime DEFAULT NULL,
  `check_in_actual` datetime DEFAULT NULL,
  `check_out_actual` datetime DEFAULT NULL,
  `rental_type` varchar(20) DEFAULT NULL,
  `price_snapshot` decimal(15,2) DEFAULT NULL,
  `room_deposit_amount` decimal(15,2) DEFAULT NULL,
  `room_deposit_original` decimal(15,2) DEFAULT NULL,
  `cancellation_refund_percent` decimal(5,2) DEFAULT NULL,
  `cancellation_fee_percent` decimal(5,2) DEFAULT NULL,
  `cancellation_refund_amount` decimal(15,2) DEFAULT NULL,
  `final_amount` decimal(15,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `price_breakdown_snapshot` json DEFAULT NULL,
  `hourly_price_snapshot` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `room_id` (`room_id`),
  KEY `ix_booking_rooms_booking_id_status` (`booking_id`,`status`),
  KEY `ix_booking_rooms_status` (`status`),
  KEY `fk_booking_rooms_hotel` (`hotel_id`),
  CONSTRAINT `booking_rooms_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`),
  CONSTRAINT `booking_rooms_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  CONSTRAINT `fk_booking_rooms_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_rooms`
--

LOCK TABLES `booking_rooms` WRITE;
/*!40000 ALTER TABLE `booking_rooms` DISABLE KEYS */;
INSERT INTO `booking_rooms` VALUES (1,1,1,'2026-08-10 07:00:00','2026-08-15 07:00:00','2026-08-10 07:00:00',NULL,'daily',400000.00,0.00,0.00,0.00,0.00,0.00,0.00,'checked_in',1,'[{\"amount\": 400000.0, \"business_date\": \"2026-08-10\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-11\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-12\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-13\"}, {\"amount\": 400000.0, \"business_date\": \"2026-08-14\"}]',NULL),(2,2,2,'2027-07-11 14:00:00','2027-07-12 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-07-11\"}]',NULL),(3,3,2,'2027-07-13 14:00:00','2027-07-14 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-07-13\"}]',NULL),(4,4,2,'2026-11-27 14:00:00','2026-11-28 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2026-11-27\"}]',NULL),(5,5,2,'2027-05-03 14:00:00','2027-05-04 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-05-03\"}]',NULL),(6,6,2,'2027-09-24 14:00:00','2027-09-25 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-09-24\"}]',NULL),(7,7,2,'2028-07-17 14:00:00','2028-07-18 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-07-17\"}]',NULL),(8,8,2,'2031-01-13 14:00:00','2031-01-14 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2031-01-13\"}]',NULL),(9,9,2,'2031-06-19 14:00:00','2031-06-20 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2031-06-19\"}]',NULL),(10,10,2,'2031-11-10 14:00:00','2031-11-11 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2031-11-10\"}]',NULL),(11,10,3,'2031-11-10 14:00:00','2031-11-11 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2031-11-10\"}]',NULL),(12,11,2,'2031-08-09 14:00:00','2031-08-10 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2031-08-09\"}]',NULL),(13,11,3,'2031-08-09 14:00:00','2031-08-10 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2031-08-09\"}]',NULL),(14,12,2,'2032-04-12 14:00:00','2032-04-13 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2032-04-12\"}]',NULL),(15,13,2,'2032-09-16 14:00:00','2032-09-17 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2032-09-16\"}]',NULL),(16,14,2,'2033-02-07 14:00:00','2033-02-08 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2033-02-07\"}]',NULL),(17,14,3,'2033-02-07 14:00:00','2033-02-08 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2033-02-07\"}]',NULL),(18,15,2,'2033-08-06 14:00:00','2033-08-07 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2033-08-06\"}]',NULL),(19,16,2,'2027-06-29 14:00:00','2027-06-30 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-06-29\"}]',NULL),(20,17,2,'2027-12-03 14:00:00','2027-12-04 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-12-03\"}]',NULL),(21,18,2,'2028-05-08 14:00:00','2028-05-09 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-05-08\"}]',NULL),(22,18,3,'2028-05-08 14:00:00','2028-05-09 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-05-08\"}]',NULL),(23,19,2,'2033-02-17 14:00:00','2033-02-18 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2033-02-17\"}]',NULL),(24,20,2,'2033-12-15 14:00:00','2033-12-16 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2033-12-15\"}]',NULL),(25,21,2,'2034-05-21 14:00:00','2034-05-22 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2034-05-21\"}]',NULL),(26,21,3,'2034-05-21 14:00:00','2034-05-22 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2034-05-21\"}]',NULL),(27,22,2,'2029-01-04 14:00:00','2029-01-05 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-01-04\"}]',NULL),(28,23,2,'2029-06-23 14:00:00','2029-06-24 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-06-23\"}]',NULL),(29,24,2,'2029-11-27 14:00:00','2029-11-28 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-11-27\"}]',NULL),(30,24,3,'2029-11-27 14:00:00','2029-11-28 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-11-27\"}]',NULL),(31,25,2,'2034-11-13 14:00:00','2034-11-14 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2034-11-13\"}]',NULL),(32,26,2,'2027-01-18 14:00:00','2027-01-19 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-01-18\"}]',NULL),(33,27,2,'2027-07-20 14:00:00','2027-07-21 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-07-20\"}]',NULL),(34,27,3,'2027-07-20 14:00:00','2027-07-21 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-07-20\"}]',NULL),(35,28,2,'2029-11-11 14:00:00','2029-11-12 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-11-11\"}]',NULL),(36,29,2,'2030-04-30 14:00:00','2030-05-01 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2030-04-30\"}]',NULL),(37,30,2,'2030-10-30 14:00:00','2030-10-31 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2030-10-30\"}]',NULL),(38,30,3,'2030-10-30 14:00:00','2030-10-31 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2030-10-30\"}]',NULL),(39,31,2,'2034-09-27 14:00:00','2034-09-28 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2034-09-27\"}]',NULL),(40,32,2,'2026-12-15 14:00:00','2026-12-16 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2026-12-15\"}]',NULL),(41,33,2,'2027-05-08 14:00:00','2027-05-09 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-05-08\"}]',NULL),(42,33,3,'2027-05-08 14:00:00','2027-05-09 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-05-08\"}]',NULL),(43,34,2,'2027-06-28 14:00:00','2027-06-29 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-06-28\"}]',NULL),(44,35,2,'2027-12-02 14:00:00','2027-12-03 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-12-02\"}]',NULL),(45,36,2,'2028-05-07 14:00:00','2028-05-08 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-05-07\"}]',NULL),(46,36,3,'2028-05-07 14:00:00','2028-05-08 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-05-07\"}]',NULL),(47,37,2,'2028-12-25 14:00:00','2028-12-26 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-12-25\"}]',NULL),(48,38,2,'2029-05-31 14:00:00','2029-06-01 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-05-31\"}]',NULL),(49,39,2,'2029-10-22 14:00:00','2029-10-23 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-10-22\"}]',NULL),(50,39,3,'2029-10-22 14:00:00','2029-10-23 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-10-22\"}]',NULL),(51,40,2,'2026-11-25 14:00:00','2026-11-26 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2026-11-25\"}]',NULL),(52,41,2,'2027-05-01 14:00:00','2027-05-02 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-05-01\"}]',NULL),(53,42,2,'2027-09-22 14:00:00','2027-09-23 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-09-22\"}]',NULL),(54,42,3,'2027-09-22 14:00:00','2027-09-23 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-09-22\"}]',NULL),(55,43,2,'2029-12-03 14:00:00','2029-12-04 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-12-03\"}]',NULL),(56,44,2,'2030-04-26 14:00:00','2030-04-27 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2030-04-26\"}]',NULL),(57,45,2,'2030-09-17 14:00:00','2030-09-18 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2030-09-17\"}]',NULL),(58,45,3,'2030-09-17 14:00:00','2030-09-18 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2030-09-17\"}]',NULL),(59,46,2,'2026-08-20 01:09:00','2026-08-21 12:00:00','2026-08-19 18:09:04',NULL,'daily',500000.00,500000.00,500000.00,0.00,0.00,0.00,0.00,'checked_in',1,'[{\"amount\": 500000.0, \"business_date\": \"2026-08-20\"}]',NULL),(60,47,2,'2027-02-14 14:00:00','2027-02-15 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-02-14\"}]',NULL),(61,48,2,'2027-07-21 14:00:00','2027-07-22 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-07-21\"}]',NULL),(62,49,2,'2027-12-12 14:00:00','2027-12-13 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-12-12\"}]',NULL),(63,49,3,'2027-12-12 14:00:00','2027-12-13 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2027-12-12\"}]',NULL),(64,50,2,'2028-05-22 14:00:00','2028-05-23 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-05-22\"}]',NULL),(65,51,2,'2028-12-17 14:00:00','2028-12-18 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2028-12-17\"}]',NULL),(66,52,2,'2029-06-05 14:00:00','2029-06-06 12:00:00',NULL,NULL,'daily',500000.00,250000.00,250000.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-06-05\"}]',NULL),(67,52,3,'2029-06-05 14:00:00','2029-06-06 12:00:00',NULL,NULL,'daily',500000.00,0.00,0.00,0.00,0.00,0.00,0.00,'booked',1,'[{\"amount\": 500000.0, \"business_date\": \"2029-06-05\"}]',NULL);
/*!40000 ALTER TABLE `booking_rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_service_batch_allocations`
--

DROP TABLE IF EXISTS `booking_service_batch_allocations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_service_batch_allocations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `booking_service_id` int NOT NULL,
  `batch_id` int NOT NULL,
  `quantity` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_booking_service_batch_allocation` (`hotel_id`,`booking_service_id`,`batch_id`),
  KEY `ix_booking_service_batch_allocations_hotel_id` (`hotel_id`),
  KEY `ix_booking_service_batch_allocations_booking_service_id` (`booking_service_id`),
  KEY `ix_booking_service_batch_allocations_batch_id` (`batch_id`),
  CONSTRAINT `booking_service_batch_allocations_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `inventory_batches` (`id`),
  CONSTRAINT `booking_service_batch_allocations_ibfk_2` FOREIGN KEY (`booking_service_id`) REFERENCES `booking_services` (`id`),
  CONSTRAINT `booking_service_batch_allocations_ibfk_3` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_service_batch_allocations`
--

LOCK TABLES `booking_service_batch_allocations` WRITE;
/*!40000 ALTER TABLE `booking_service_batch_allocations` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_service_batch_allocations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `booking_services`
--

DROP TABLE IF EXISTS `booking_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `booking_services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `room_id` int NOT NULL,
  `service_id` int NOT NULL,
  `quantity` int DEFAULT NULL,
  `price_at_booking` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `booking_id` (`booking_id`),
  KEY `room_id` (`room_id`),
  KEY `service_id` (`service_id`),
  KEY `fk_booking_services_hotel` (`hotel_id`),
  CONSTRAINT `booking_services_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`),
  CONSTRAINT `booking_services_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`),
  CONSTRAINT `booking_services_ibfk_3` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`),
  CONSTRAINT `fk_booking_services_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `booking_services`
--

LOCK TABLES `booking_services` WRITE;
/*!40000 ALTER TABLE `booking_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `booking_services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `customer_id` int NOT NULL,
  `total_amount` decimal(15,2) DEFAULT NULL,
  `prepaid_amount` decimal(15,2) DEFAULT NULL,
  `payment_status` varchar(20) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `note` varchar(1000) DEFAULT NULL,
  `source` varchar(50) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `customer_id` (`customer_id`),
  KEY `ix_bookings_status` (`status`),
  KEY `fk_bookings_hotel` (`hotel_id`),
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`),
  CONSTRAINT `fk_bookings_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (1,'BK-SMOKE-01',1,0.00,0.00,'partial','pending',NULL,'walk_in','2026-08-14 08:59:47','2026-08-14 08:59:47',1,NULL),(2,'BK-260815-5VWZ',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:30:58','2026-08-15 04:30:58',1,NULL),(3,'BK-260815-56T3',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:32:12','2026-08-15 04:32:12',1,NULL),(4,'BK-260815-W9AP',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:33:08','2026-08-15 04:33:08',1,NULL),(5,'BK-260815-5CG6',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:33:10','2026-08-15 04:33:10',1,NULL),(6,'BK-260815-6WDS',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:33:11','2026-08-15 04:33:11',1,NULL),(7,'BK-260815-5NH8',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:33:55','2026-08-15 04:33:55',1,NULL),(8,'BK-260815-M3MY',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:04','2026-08-15 04:35:04',1,NULL),(9,'BK-260815-EG5S',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:06','2026-08-15 04:35:06',1,NULL),(10,'BK-260815-QYQT',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:07','2026-08-15 04:35:07',1,NULL),(11,'BK-260815-QV8Q',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:20','2026-08-15 04:35:20',1,NULL),(12,'BK-260815-ELFW',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:40','2026-08-15 04:35:40',1,NULL),(13,'BK-260815-7NNA',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:42','2026-08-15 04:35:42',1,NULL),(14,'BK-260815-FZQA',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:35:43','2026-08-15 04:35:43',1,NULL),(15,'BK-260815-T3PP',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 04:36:17','2026-08-15 04:36:17',1,NULL),(16,'BK-260815-4TGR',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:11:06','2026-08-15 07:11:06',1,NULL),(17,'BK-260815-YSBJ',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:11:09','2026-08-15 07:11:09',1,NULL),(18,'BK-260815-MFMB',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:11:11','2026-08-15 07:11:11',1,NULL),(19,'BK-260815-NXAY',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:21:27','2026-08-15 07:21:27',1,NULL),(20,'BK-260815-WC3T',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:21:30','2026-08-15 07:21:30',1,NULL),(21,'BK-260815-AD2H',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:21:31','2026-08-15 07:21:31',1,NULL),(22,'BK-260815-8BV9',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:23:22','2026-08-15 07:23:22',1,NULL),(23,'BK-260815-W9J6',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:23:25','2026-08-15 07:23:25',1,NULL),(24,'BK-260815-YB5G',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 07:23:26','2026-08-15 07:23:26',1,NULL),(25,'BK-260815-57ZT',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 13:58:24','2026-08-15 13:58:24',1,NULL),(26,'BK-260815-XDUS',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 13:58:26','2026-08-15 13:58:26',1,NULL),(27,'BK-260815-JTSK',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 13:58:29','2026-08-15 13:58:29',1,NULL),(28,'BK-260815-89EA',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 14:19:09','2026-08-15 14:19:09',1,NULL),(29,'BK-260815-H9PV',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 14:19:12','2026-08-15 14:19:12',1,NULL),(30,'BK-260815-UKVH',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 14:19:15','2026-08-15 14:19:15',1,NULL),(31,'BK-260815-LBUP',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 14:21:25','2026-08-15 14:21:25',1,NULL),(32,'BK-260815-UGJ6',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 14:21:27','2026-08-15 14:21:27',1,NULL),(33,'BK-260815-L2U4',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-15 14:21:28','2026-08-15 14:21:28',1,NULL),(34,'BK-260819-CGWN',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:48:02','2026-08-19 15:48:02',1,NULL),(35,'BK-260819-DFW3',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:48:04','2026-08-19 15:48:04',1,NULL),(36,'BK-260819-QHAM',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:48:05','2026-08-19 15:48:05',1,NULL),(37,'BK-260819-KM6J',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:48:44','2026-08-19 15:48:44',1,NULL),(38,'BK-260819-U8PK',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:48:46','2026-08-19 15:48:46',1,NULL),(39,'BK-260819-JM2K',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:48:47','2026-08-19 15:48:47',1,NULL),(40,'BK-260819-YKY2',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:55:26','2026-08-19 15:55:26',1,NULL),(41,'BK-260819-QY4N',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:55:28','2026-08-19 15:55:28',1,NULL),(42,'BK-260819-TG2A',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 15:55:29','2026-08-19 15:55:29',1,NULL),(43,'BK-260820-NRFB',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 18:07:37','2026-08-19 18:07:37',1,NULL),(44,'BK-260820-AVZF',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 18:07:39','2026-08-19 18:07:39',1,NULL),(45,'BK-260820-CQMR',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 18:07:40','2026-08-19 18:07:40',1,NULL),(46,'BK-260820-UD56',6,0.00,500000.00,'partial','checked_in',NULL,'walk_in','2026-08-19 18:09:04','2026-08-19 18:09:04',1,NULL),(47,'BK-260820-UEW5',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 18:44:47','2026-08-19 18:44:47',1,NULL),(48,'BK-260820-XKJ9',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 18:44:49','2026-08-19 18:44:49',1,NULL),(49,'BK-260820-9VS3',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-19 18:44:50','2026-08-19 18:44:50',1,NULL),(50,'BK-260821-4JS7',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-21 10:37:40','2026-08-21 10:37:40',1,NULL),(51,'BK-260821-W8HY',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-21 10:37:46','2026-08-21 10:37:46',1,NULL),(52,'BK-260821-2TAZ',2,0.00,250000.00,'partial','confirmed',NULL,'walk_in','2026-08-21 10:37:50','2026-08-21 10:37:50',1,NULL);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `business_operations`
--

DROP TABLE IF EXISTS `business_operations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `business_operations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `operation_key` varchar(120) NOT NULL,
  `action` varchar(50) NOT NULL,
  `entity_type` varchar(50) NOT NULL,
  `entity_id` int NOT NULL,
  `status` varchar(20) NOT NULL,
  `created_at` datetime NOT NULL,
  `completed_at` datetime DEFAULT NULL,
  `request_fingerprint` varchar(64) DEFAULT NULL,
  `result_snapshot` json DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_hotel_operation_key_uc` (`hotel_id`,`operation_key`),
  KEY `ix_business_operations_hotel_entity` (`hotel_id`,`entity_type`,`entity_id`),
  CONSTRAINT `business_operations_ibfk_1` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `business_operations`
--

LOCK TABLES `business_operations` WRITE;
/*!40000 ALTER TABLE `business_operations` DISABLE KEYS */;
INSERT INTO `business_operations` VALUES (1,1,'refund:1:live-wrong','create_refund','booking',1,'completed','2026-08-14 09:00:09','2026-08-14 09:00:09','03725767bfcdf68bf8bc9dae1daffff51a73e08760d22e2e04a6b200a7ab52c0','{\"base\": \"total\", \"percent\": null, \"success\": true, \"payment_id\": 2, \"refund_amount\": \"350000.00\"}'),(2,1,'refund_reversal:2:live-fix','reverse_refund','payment',2,'completed','2026-08-14 09:00:09','2026-08-14 09:00:09','3517efec2c336ed5eddeaae1873427fdbde63a40cb5cfe2780994b16d6629d58','{\"amount\": \"350000.00\", \"success\": true, \"payment_id\": 3, \"reverses_payment_id\": 2}'),(3,1,'refund:1:live-correct','create_refund','booking',1,'completed','2026-08-14 09:00:09','2026-08-14 09:00:09','07712d2c654c2bec2211d378193863b6cc7ee7421d2c237b4c686223e8716b2f','{\"base\": \"total\", \"percent\": null, \"success\": true, \"payment_id\": 4, \"refund_amount\": \"35000.00\"}');
/*!40000 ALTER TABLE `business_operations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `phone` varchar(15) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `cccd` varchar(12) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `cccd` (`cccd`),
  UNIQUE KEY `email` (`email`),
  KEY `fk_customers_hotel` (`hotel_id`),
  CONSTRAINT `fk_customers_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
INSERT INTO `customers` VALUES (1,'Nguyen Van A','0901234567',NULL,NULL,NULL,1),(2,'Khach Smoke','0909000111',NULL,NULL,NULL,1),(6,'Khách lẻ',NULL,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `expenses`
--

DROP TABLE IF EXISTS `expenses`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `expenses` (
  `id` int NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  `description` varchar(255) NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `expense_date` date NOT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `is_voided` tinyint(1) NOT NULL DEFAULT '0',
  `void_reason` varchar(255) DEFAULT NULL,
  `voided_at` datetime DEFAULT NULL,
  `voided_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `created_by` (`created_by`),
  KEY `fk_expenses_hotel` (`hotel_id`),
  KEY `fk_expenses_voided_by_users` (`voided_by`),
  CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_expenses_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `fk_expenses_voided_by_users` FOREIGN KEY (`voided_by`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `expenses`
--

LOCK TABLES `expenses` WRITE;
/*!40000 ALTER TABLE `expenses` DISABLE KEYS */;
/*!40000 ALTER TABLE `expenses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hotels`
--

DROP TABLE IF EXISTS `hotels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `hotels` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(50) NOT NULL,
  `address` text,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `logo_url` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hotels`
--

LOCK TABLES `hotels` WRITE;
/*!40000 ALTER TABLE `hotels` DISABLE KEYS */;
INSERT INTO `hotels` VALUES (1,'Khách sạn Trung tâm','central',NULL,NULL,NULL,NULL,1,NULL);
/*!40000 ALTER TABLE `hotels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_batches`
--

DROP TABLE IF EXISTS `inventory_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_batches` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `inventory_item_id` int NOT NULL,
  `expense_id` int DEFAULT NULL,
  `batch_code` varchar(64) NOT NULL,
  `received_at` date NOT NULL,
  `expires_at` date DEFAULT NULL,
  `quantity_received` int NOT NULL,
  `quantity_available` int NOT NULL,
  `unit_cost` decimal(15,2) NOT NULL DEFAULT '0.00',
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `_hotel_inventory_batch_code_uc` (`hotel_id`,`batch_code`),
  KEY `created_by` (`created_by`),
  KEY `expense_id` (`expense_id`),
  KEY `ix_inventory_batches_hotel_id` (`hotel_id`),
  KEY `ix_inventory_batches_inventory_item_id` (`inventory_item_id`),
  CONSTRAINT `inventory_batches_ibfk_1` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_batches_ibfk_2` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`),
  CONSTRAINT `inventory_batches_ibfk_3` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `inventory_batches_ibfk_4` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_batches`
--

LOCK TABLES `inventory_batches` WRITE;
/*!40000 ALTER TABLE `inventory_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_items`
--

DROP TABLE IF EXISTS `inventory_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_items` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `quantity` int DEFAULT NULL,
  `min_quantity` int DEFAULT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `service_id` int DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `code` (`code`),
  KEY `service_id` (`service_id`),
  KEY `fk_inventory_items_hotel` (`hotel_id`),
  CONSTRAINT `fk_inventory_items_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `inventory_items_ibfk_1` FOREIGN KEY (`service_id`) REFERENCES `services` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_items`
--

LOCK TABLES `inventory_items` WRITE;
/*!40000 ALTER TABLE `inventory_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_movements`
--

DROP TABLE IF EXISTS `inventory_movements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `inventory_movements` (
  `id` int NOT NULL AUTO_INCREMENT,
  `hotel_id` int NOT NULL,
  `inventory_item_id` int NOT NULL,
  `batch_id` int DEFAULT NULL,
  `expense_id` int DEFAULT NULL,
  `booking_service_id` int DEFAULT NULL,
  `movement_type` varchar(20) NOT NULL,
  `quantity_delta` int NOT NULL,
  `reason` varchar(100) NOT NULL,
  `note` varchar(500) DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `booking_service_id` (`booking_service_id`),
  KEY `created_by` (`created_by`),
  KEY `expense_id` (`expense_id`),
  KEY `ix_inventory_movements_hotel_id` (`hotel_id`),
  KEY `ix_inventory_movements_inventory_item_id` (`inventory_item_id`),
  KEY `ix_inventory_movements_batch_id` (`batch_id`),
  CONSTRAINT `inventory_movements_ibfk_1` FOREIGN KEY (`batch_id`) REFERENCES `inventory_batches` (`id`),
  CONSTRAINT `inventory_movements_ibfk_2` FOREIGN KEY (`booking_service_id`) REFERENCES `booking_services` (`id`),
  CONSTRAINT `inventory_movements_ibfk_3` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `inventory_movements_ibfk_4` FOREIGN KEY (`expense_id`) REFERENCES `expenses` (`id`),
  CONSTRAINT `inventory_movements_ibfk_5` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `inventory_movements_ibfk_6` FOREIGN KEY (`inventory_item_id`) REFERENCES `inventory_items` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_movements`
--

LOCK TABLES `inventory_movements` WRITE;
/*!40000 ALTER TABLE `inventory_movements` DISABLE KEYS */;
/*!40000 ALTER TABLE `inventory_movements` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `booking_id` int NOT NULL,
  `amount` decimal(15,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_type` varchar(50) DEFAULT NULL,
  `note` text,
  `created_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  `business_operation_id` int DEFAULT NULL,
  `component_key` varchar(120) DEFAULT NULL,
  `reverses_payment_id` int DEFAULT NULL,
  `created_by` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payments_operation_component` (`hotel_id`,`business_operation_id`,`component_key`),
  UNIQUE KEY `uq_payments_reverses_once` (`reverses_payment_id`),
  KEY `ix_payments_booking_id` (`booking_id`),
  KEY `fk_payments_business_operation` (`business_operation_id`),
  KEY `ix_payments_hotel_booking` (`hotel_id`,`booking_id`),
  KEY `fk_payments_created_by_user` (`created_by`),
  CONSTRAINT `fk_payments_business_operation` FOREIGN KEY (`business_operation_id`) REFERENCES `business_operations` (`id`),
  CONSTRAINT `fk_payments_created_by_user` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  CONSTRAINT `fk_payments_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`),
  CONSTRAINT `fk_payments_reverses_payment` FOREIGN KEY (`reverses_payment_id`) REFERENCES `payments` (`id`),
  CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`booking_id`) REFERENCES `bookings` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payments`
--

LOCK TABLES `payments` WRITE;
/*!40000 ALTER TABLE `payments` DISABLE KEYS */;
INSERT INTO `payments` VALUES (1,1,500000.00,'cash','deposit','Cọc smoke','2026-08-14 08:59:47',1,NULL,NULL,NULL,NULL),(2,1,-350000.00,'cash','refund','Hoàn tiền đơn BK-SMOKE-01: Nhap nham 70%','2026-08-14 09:00:09',1,1,'refund',NULL,NULL),(3,1,350000.00,'cash','refund_reversal','Điều chỉnh hoàn sai (dòng #2): Nhap nham, dao lai','2026-08-14 09:00:09',1,2,'refund_reversal',2,NULL),(4,1,-35000.00,'cash','refund','Hoàn tiền đơn BK-SMOKE-01: Hoan dung 7%','2026-08-14 09:00:09',1,3,'refund',NULL,NULL),(5,2,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:30:58',1,NULL,NULL,NULL,1),(6,3,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:32:12',1,NULL,NULL,NULL,1),(7,4,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:33:08',1,NULL,NULL,NULL,1),(8,5,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:33:10',1,NULL,NULL,NULL,1),(9,6,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:33:11',1,NULL,NULL,NULL,1),(10,7,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:33:55',1,NULL,NULL,NULL,1),(11,8,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:04',1,NULL,NULL,NULL,1),(12,9,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:06',1,NULL,NULL,NULL,1),(13,10,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:07',1,NULL,NULL,NULL,1),(14,11,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:20',1,NULL,NULL,NULL,1),(15,12,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:40',1,NULL,NULL,NULL,1),(16,13,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:42',1,NULL,NULL,NULL,1),(17,14,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:35:43',1,NULL,NULL,NULL,1),(18,15,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 04:36:17',1,NULL,NULL,NULL,1),(19,16,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:11:06',1,NULL,NULL,NULL,1),(20,17,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:11:09',1,NULL,NULL,NULL,1),(21,18,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:11:11',1,NULL,NULL,NULL,1),(22,19,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:21:27',1,NULL,NULL,NULL,1),(23,20,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:21:30',1,NULL,NULL,NULL,1),(24,21,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:21:31',1,NULL,NULL,NULL,1),(25,22,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:23:22',1,NULL,NULL,NULL,1),(26,23,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:23:25',1,NULL,NULL,NULL,1),(27,24,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 07:23:26',1,NULL,NULL,NULL,1),(28,25,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 13:58:24',1,NULL,NULL,NULL,1),(29,26,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 13:58:26',1,NULL,NULL,NULL,1),(30,27,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 13:58:29',1,NULL,NULL,NULL,1),(31,28,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 14:19:09',1,NULL,NULL,NULL,1),(32,29,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 14:19:12',1,NULL,NULL,NULL,1),(33,30,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 14:19:15',1,NULL,NULL,NULL,1),(34,31,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 14:21:25',1,NULL,NULL,NULL,1),(35,32,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 14:21:27',1,NULL,NULL,NULL,1),(36,33,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-15 14:21:28',1,NULL,NULL,NULL,1),(37,34,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:48:02',1,NULL,NULL,NULL,1),(38,35,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:48:04',1,NULL,NULL,NULL,1),(39,36,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:48:05',1,NULL,NULL,NULL,1),(40,37,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:48:44',1,NULL,NULL,NULL,1),(41,38,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:48:46',1,NULL,NULL,NULL,1),(42,39,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:48:47',1,NULL,NULL,NULL,1),(43,40,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:55:26',1,NULL,NULL,NULL,1),(44,41,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:55:28',1,NULL,NULL,NULL,1),(45,42,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 15:55:29',1,NULL,NULL,NULL,1),(46,43,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:07:37',1,NULL,NULL,NULL,1),(47,44,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:07:39',1,NULL,NULL,NULL,1),(48,45,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:07:40',1,NULL,NULL,NULL,1),(49,46,500000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:09:04',1,NULL,NULL,NULL,1),(50,47,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:44:47',1,NULL,NULL,NULL,1),(51,48,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:44:49',1,NULL,NULL,NULL,1),(52,49,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-19 18:44:50',1,NULL,NULL,NULL,1),(53,50,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-21 10:37:40',1,NULL,NULL,NULL,1),(54,51,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-21 10:37:46',1,NULL,NULL,NULL,1),(55,52,250000.00,'cash','deposit','Tiền cọc đặt phòng 701','2026-08-21 10:37:50',1,NULL,NULL,NULL,1);
/*!40000 ALTER TABLE `payments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `price_rules`
--

DROP TABLE IF EXISTS `price_rules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `price_rules` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `room_type` varchar(50) NOT NULL,
  `is_active` tinyint(1) DEFAULT NULL,
  `priority` int DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `days_of_week` varchar(20) DEFAULT NULL,
  `price_daily` decimal(10,2) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_price_rules_hotel` (`hotel_id`),
  CONSTRAINT `fk_price_rules_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `price_rules`
--

LOCK TABLES `price_rules` WRITE;
/*!40000 ALTER TABLE `price_rules` DISABLE KEYS */;
/*!40000 ALTER TABLE `price_rules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rooms` (
  `id` int NOT NULL AUTO_INCREMENT,
  `room_number` varchar(10) NOT NULL,
  `room_type` varchar(20) DEFAULT NULL,
  `price_per_night` int NOT NULL,
  `price_initial_block` int NOT NULL,
  `initial_hours` int NOT NULL,
  `price_next_hour` decimal(10,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `clean_status` varchar(20) DEFAULT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_rooms_hotel_room_number` (`hotel_id`,`room_number`),
  CONSTRAINT `fk_rooms_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rooms`
--

LOCK TABLES `rooms` WRITE;
/*!40000 ALTER TABLE `rooms` DISABLE KEYS */;
INSERT INTO `rooms` VALUES (1,'101','Standard',400000,100000,2,50000.00,'available','cleaned',1),(2,'701','Standard',500000,100000,2,50000.00,'occupied','cleaned',1),(3,'702','Standard',500000,100000,2,50000.00,'available','cleaned',1);
/*!40000 ALTER TABLE `rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `services`
--

DROP TABLE IF EXISTS `services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `services` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `price` int NOT NULL,
  `hotel_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_services_hotel` (`hotel_id`),
  CONSTRAINT `fk_services_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `services`
--

LOCK TABLES `services` WRITE;
/*!40000 ALTER TABLE `services` DISABLE KEYS */;
/*!40000 ALTER TABLE `services` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(20) DEFAULT NULL,
  `fs_uniquifier` varchar(64) NOT NULL,
  `hotel_id` int DEFAULT NULL,
  `is_super_admin` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `fs_uniquifier` (`fs_uniquifier`),
  UNIQUE KEY `username` (`username`),
  KEY `fk_users_hotel` (`hotel_id`),
  CONSTRAINT `fk_users_hotel` FOREIGN KEY (`hotel_id`) REFERENCES `hotels` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'admin','scrypt:32768:8:1$xDY4k186XczTQrtM$0bbe0a20ab283e9f3f3d1eaf3e892e271e595f6f90680d2b9eb4fc3a1cd283d22f176535e973cdb16feb4e6721f709d0c46977bda081d45f46681109990c7c8d','admin','280208fa-1177-42bd-8575-90e80dcf5cf4',1,0),(2,'staff1','scrypt:32768:8:1$WXR3mysQyp7WhTHK$b2fe8a27bdda9359584581e349fc60a074b0a8e8974dd8c409baa179b9b703d6368065051c0e315162bed629a06a60242ed3ad3fdcec6ccfb30729a14e1cac07','staff','80a25fc8-b205-4ea6-9840-484e16cee164',1,0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'hotel'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-21 17:24:25
